// Deprecated. Moved to root i18nUtils.ts.
export {};