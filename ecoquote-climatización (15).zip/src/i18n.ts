// Deprecated. Moved to root i18n.ts.
export {};