// Deprecated. Moved to root locales/ca.ts.
export {};