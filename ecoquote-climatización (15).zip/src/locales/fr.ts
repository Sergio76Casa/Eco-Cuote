// Deprecated. Moved to root locales/fr.ts.
export {};