// Deprecated. Moved to root locales/es.ts.
export {};